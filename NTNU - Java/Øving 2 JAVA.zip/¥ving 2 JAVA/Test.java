package oving2;

public class Test {
    public static void main(String args[])
    {
        String str = "Simon Sandvik Lee";
        String[] arrOfStr = str.split(" ");
 
        System.out.println(arrOfStr[0]);
    }
}
