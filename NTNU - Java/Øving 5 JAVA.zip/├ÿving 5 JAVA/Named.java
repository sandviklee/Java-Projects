package oving5;

public interface Named {
    
    public void setGivenName(String givenName);

    public String getGivenName();

    public void setFamilyName(String familyName);

    public String getFamilyName();

    public void setFullName(String fullName);

    public String getFullName();

    
}
